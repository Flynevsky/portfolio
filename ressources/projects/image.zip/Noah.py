def teinte(image):
    from PIL import Image
    import time
    from datetime import datetime
    heure1 = datetime.now()##mesure le temps du programme en prenant son heure de départ
    x,y=image.size
    teinte_initiale=int(input("Indiquez la valeur de la teinte souhaitée (de -300 à 300)\n"))
    while teinte_initiale > 300 or teinte_initiale < -300 :
        print("Mais t'es débile où tu le fais exprès ? J'ai dis entre -300 et 300, [300;300] c'est pas compliqué !")
        time.sleep(5)
        teinte_initiale=int(input("Indiquez la valeur de la teinte souhaitée (de -300 à 300)\n"))
    ## POUR TEINTE SUPERIEUR
    if teinte_initiale > 0 and teinte_initiale <= 300 :
        ##attribution des coefficients
        if teinte_initiale > 100:
            teinte=1
        if teinte_initiale > 200:
            teinte_01=100
        if teinte_initiale <= 100:
            teinte=0.01*teinte_initiale
        if teinte_initiale <= 200 and teinte_initiale >100:
            teinte_01=1*(teinte_initiale-100)
        if teinte_initiale <= 300 and teinte_initiale >200:
            teinte_02=teinte_initiale-200
        print(teinte)
        ##première partie pour les teintes de 0 à -100 (coef déjà attribués)
        for i in range(0,x):
            for p in range (0,y):
                (R,G,B,A)=image.getpixel((i,p))
                ##pour un pixel avec rouge dominant
                if R>B and R>=G :
                    ##avec bleu dominant vert
                    ##pour chaque combinaison de dominant, milieu, dominé de RGB (ex : R=209(dominant) G=30(dominé) B=50(milieu))
                    if B>G :
                        pas1=R-G
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=R-B
                        if pas2 >= pas1:
                            B_modif=B-pas1
                            image.putpixel((i,p),(R,G,B_modif,A))
                        else:
                            B_modif=G
                            G_modif=G+pas2
                            image.putpixel((i,p),(R,G_modif,B_modif,A))
                    ##avec vert dominant bleu
                    else :
                        pas1=R-B
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=R-G
                        if pas2 >= pas1:
                            G_modif=G+pas1
                            image.putpixel((i,p),(R,G_modif,B,A))
                        else:
                            pas3=pas1-pas2
                            G_modif=R
                            R_modif=R-pas3
                            image.putpixel((i,p),(R_modif,G_modif,B,A))
                ##pour un pixel avec bleu dominant
                if B>=R and B>G :
                    if G>R :
                        pas1=B-R
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=B-G
                        if pas2 >= pas1:
                            G_modif=G-pas1
                            image.putpixel((i,p),(R,G_modif,B,A))
                        else:
                            G_modif=R
                            R_modif=R+pas2
                            image.putpixel((i,p),(R_modif,G_modif,B,A))
                    else :
                        pas1=B-G
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=B-R
                        if pas2 >= pas1:
                            R_modif=R+pas1
                            image.putpixel((i,p),(R_modif,G,B,A))
                        else:
                            pas3=pas1-pas2
                            R_modif=B
                            B_modif=B-pas3
                            image.putpixel((i,p),(R_modif,G,B_modif,A))
                ##pour un pixel avec vert dominant
                if G>=B and G>R :
                    if R>B :
                        pas1=G-B
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=G-R
                        if pas2 >= pas1:
                            R_modif=R-pas1
                            image.putpixel((i,p),(R_modif,G,B,A))
                        else:
                            R_modif=B
                            B_modif=B+pas2
                            image.putpixel((i,p),(R_modif,G,B_modif,A))
                    else :
                        pas1=G-R
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=G-B
                        if pas2 >= pas1:
                            B_modif=B+pas1
                            image.putpixel((i,p),(R,G,B_modif,A))
                        else:
                            pas3=pas1-pas2
                            B_modif=G
                            G_modif=G-pas3
                            image.putpixel((i,p),(R,G_modif,B_modif,A))
        ##deuxième partie pour les teintes de 0 à 200
        if teinte_initiale > 100 :
            teinte=0.01*teinte_01
            print(teinte)
            for i in range(0,x):
                for p in range (0,y):
                    (R,G,B,A)=image.getpixel((i,p))
                    ##pour un pixel avec rouge dominant
                    if R>B and R>=G :
                        if B>G :
                            pas1=R-G
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-B
                            if pas2 >= pas1:
                                B_modif=B-pas1
                                image.putpixel((i,p),(R,G,B_modif,A))
                            else:
                                B_modif=G
                                G_modif=G+pas2
                                image.putpixel((i,p),(R,G_modif,B_modif,A))
                        else :
                            pas1=R-B
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-G
                            if pas2 >= pas1:
                                G_modif=G+pas1
                                image.putpixel((i,p),(R,G_modif,B,A))
                            else:
                                pas3=pas1-pas2
                                G_modif=R
                                R_modif=R-pas3
                                image.putpixel((i,p),(R_modif,G_modif,B,A))
                    ##pour un pixel avec bleu dominant
                    if B>=R and B>G :
                        if G>R :
                            pas1=B-R
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=B-G
                            if pas2 >= pas1:
                                G_modif=G-pas1
                                image.putpixel((i,p),(R,G_modif,B,A))
                            else:
                                G_modif=R
                                R_modif=R+pas2
                                image.putpixel((i,p),(R_modif,G_modif,B,A))
                        else :
                            pas1=B-G
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=B-R
                            if pas2 >= pas1:
                                R_modif=R+pas1
                                image.putpixel((i,p),(R_modif,G,B,A))
                            else:
                                pas3=pas1-pas2
                                R_modif=B
                                B_modif=B-pas3
                                image.putpixel((i,p),(R_modif,G,B_modif,A))
                    ##pour un pixel avec vert dominant
                    if G>=B and G>R :
                        if R>B :
                            pas1=G-B
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-B
                            if pas2 >= pas1:
                                R_modif=R-pas1
                                image.putpixel((i,p),(R_modif,G,B,A))
                            else:
                                R_modif=B
                                B_modif=B+pas2
                                image.putpixel((i,p),(R_modif,G,B_modif,A))
                        else :
                            pas1=G-R
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=G-B
                            if pas2 >= pas1:
                                B_modif=B+pas1
                                image.putpixel((i,p),(R,G,B_modif,A))
                            else:
                                pas3=pas1-pas2
                                B_modif=G
                                G_modif=G-pas3
                                image.putpixel((i,p),(R,G_modif,B_modif,A))
        ##3ème parite pour les teintes de 0 à 300
        if teinte_initiale > 200 and teinte_initiale <= 300:
            teinte=0.01*teinte_02
            print(teinte)
            for i in range(0,x):
                for p in range (0,y):
                    (R,G,B,A)=image.getpixel((i,p))
                    ##pour un pixel avec rouge dominant
                    if R>B and R>=G :
                        if B>G :
                            pas1=R-G
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=B-G
                            if pas2 >= pas1:
                                B_modif=B-pas1
                                image.putpixel((i,p),(R,G,B_modif,A))
                            else:
                                B_modif=G
                                G_modif=G+pas2
                                image.putpixel((i,p),(R,G_modif,B_modif,A))
                        else :
                            pas1=R-B
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-G
                            if pas2 >= pas1:
                                G_modif=G+pas1
                                image.putpixel((i,p),(R,G_modif,B,A))
                            else:
                                pas3=pas1-pas2
                                G_modif=R
                                R_modif=R-pas3
                                image.putpixel((i,p),(R_modif,G_modif,B,A))
                    ##pour un pixel avec bleu dominant
                    if B>=R and B>G :
                        if G>R :
                            pas1=B-R
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=G-R
                            if pas2 >= pas1:
                                G_modif=G-pas1
                                image.putpixel((i,p),(R,G_modif,B,A))
                            else:
                                G_modif=R
                                R_modif=R+pas2
                                image.putpixel((i,p),(R_modif,G_modif,B,A))
                        else :
                            pas1=B-G
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=B-R
                            if pas2 >= pas1:
                                R_modif=R+pas1
                                image.putpixel((i,p),(R_modif,G,B,A))
                            else:
                                pas3=pas1-pas2
                                R_modif=B
                                B_modif=B-pas3
                                image.putpixel((i,p),(R_modif,G,B_modif,A))
                    ##pour un pixel avec vert dominant
                    if G>=B and G>R :
                        if R>B :
                            pas1=G-B
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-B
                            if pas2 >= pas1:
                                R_modif=R-pas1
                                image.putpixel((i,p),(R_modif,G,B,A))
                            else:
                                R_modif=B
                                B_modif=B+(pas1-pas2)
                                image.putpixel((i,p),(R_modif,G,B_modif,A))
                        else :
                            pas1=G-R
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=G-B
                            if pas2 >= pas1:
                                B_modif=B+pas1
                                image.putpixel((i,p),(R,G,B_modif,A))
                            else:
                                pas3=pas1-pas2
                                B_modif=G
                                G_modif=G-pas3
                                image.putpixel((i,p),(R,G_modif,B_modif,A))
    ## POUR TEINTE INFERIEUR
    if teinte_initiale < 0 :
        ##attribution des coefficients
        if teinte_initiale < -100:
            teinte=1
        if teinte_initiale < -200:
            teinte_01=100
        if teinte_initiale >= -100:
            teinte=-0.01*teinte_initiale
        if teinte_initiale >= -200 and teinte_initiale <-100:
            teinte_01=-1*(teinte_initiale-(-100))
        if teinte_initiale >= -300 and teinte_initiale <-200:
            teinte_02=teinte_initiale-(-200)
        print(teinte)
        ##boucles pour chaque pixel
        ##première partie pour les teintes de 0 à -100 (coef déjà attribués)
        for i in range(0,x):
            for p in range (0,y):
                (R,G,B,A)=image.getpixel((i,p))
                ##pour un pixel avec rouge dominant
                if R>B and R>=G :
                    if B>=G :
                        pas1=R-G
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=R-B
                        if pas2 >= pas1:
                            B_modif=B+pas1
                            image.putpixel((i,p),(R,G,B_modif,A))
                        else:
                            pas3=pas1-pas2
                            B_modif=R
                            R_modif=R-pas3
                            image.putpixel((i,p),(R_modif,G,B_modif,A))
                    else :
                        pas1=R-B
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=G-B
                        if pas2 >= pas1:
                            G_modif=G-pas1
                            image.putpixel((i,p),(R,G_modif,B,A))
                        else:
                            pas3=pas1-pas2
                            G_modif=B
                            B_modif=B+pas3
                            image.putpixel((i,p),(R,G_modif,B_modif,A))
                ##pour un pixel avec bleu dominant
                if B>=R and B>G :
                    if G>=R :
                        pas1=B-R
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=B-G
                        if pas2 >= pas1:
                            G_modif=G+pas1
                            image.putpixel((i,p),(R,G_modif,B,A))
                        else:
                            pas3=pas1-pas2
                            G_modif=B
                            B_modif=B-pas3
                            image.putpixel((i,p),(R,G_modif,B_modif,A))
                    else :
                        pas1=B-G
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=B-R
                        if pas2 >= pas1:
                            R_modif=R-pas1
                            image.putpixel((i,p),(R_modif,G,B,A))
                        else:
                            pas3=pas1-pas2
                            R_modif=G
                            G_modif=G+pas3
                            image.putpixel((i,p),(R_modif,G_modif,B,A))
                ##pour un pixel avec vert dominant
                if G>=B and G>R :
                    if R>=B :
                        pas1=G-B
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=G-R
                        if pas2 >= pas1:
                            R_modif=R+pas1
                            image.putpixel((i,p),(R_modif,G,B,A))
                        else:
                            pas3=pas1-pas2
                            R_modif=G
                            G_modif=G-pas3
                            image.putpixel((i,p),(R_modif,G_modif,B,A))
                    else :
                        pas1=G-R
                        pas1=pas1*teinte
                        pas1=int(pas1)
                        pas2=B-R
                        if pas2 >= pas1:
                            B_modif=B-pas1
                            image.putpixel((i,p),(R,G,B_modif,A))
                        else:
                            pas3=pas1-pas2
                            B_modif=R
                            R_modif=R+pas3
                            image.putpixel((i,p),(R_modif,G,B_modif,A))
        ##deuxième partie pour les teintes de 0 à -200
        if teinte_initiale < -100 :
            teinte=0.01*teinte_01
            print(teinte)
            for i in range(0,x):
                for p in range (0,y):
                    (R,G,B,A)=image.getpixel((i,p))
                    ##pour un pixel avec rouge dominant
                    if R>B and R>=G :
                        if B>=G :
                            pas1=R-G
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-B
                            if pas2 >= pas1:
                                B_modif=B+pas1
                                image.putpixel((i,p),(R,G,B_modif,A))
                            else:
                                pas3=pas1-pas2
                                B_modif=R
                                R_modif=R-pas3
                                image.putpixel((i,p),(R_modif,G,B_modif,A))
                        else :
                            pas1=R-B
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=G-B
                            if pas2 >= pas1:
                                G_modif=G-pas1
                                image.putpixel((i,p),(R,G_modif,B,A))
                            else:
                                pas3=pas1-pas2
                                G_modif=B
                                B_modif=B+pas3
                                image.putpixel((i,p),(R,G_modif,B_modif,A))
                    ##pour un pixel avec bleu dominant
                    if B>=R and B>G :
                        if G>=R :
                            pas1=B-R
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=B-G
                            if pas2 >= pas1:
                                G_modif=G+pas1
                                image.putpixel((i,p),(R,G_modif,B,A))
                            else:
                                pas3=pas1-pas2
                                G_modif=B
                                B_modif=B-pas3
                                image.putpixel((i,p),(R,G_modif,B_modif,A))
                        else :
                            pas1=B-G
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-G
                            if pas2 >= pas1:
                                R_modif=R-pas1
                                image.putpixel((i,p),(R_modif,G,B,A))
                            else:
                                pas3=pas1-pas2
                                R_modif=G
                                G_modif=G+pas3
                                image.putpixel((i,p),(R_modif,G_modif,B,A))
                    ##pour un pixel avec vert dominant
                    if G>=B and G>R :
                        if R>=B :
                            pas1=G-B
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=G-R
                            if pas2 >= pas1:
                                R_modif=R+pas1
                                image.putpixel((i,p),(R_modif,G,B,A))
                            else:
                                pas3=pas1-pas2
                                R_modif=G
                                G_modif=G-pas3
                                image.putpixel((i,p),(R_modif,G_modif,B,A))
                        else :
                            pas1=G-R
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=B-R
                            if pas2 >= pas1:
                                B_modif=B-pas1
                                image.putpixel((i,p),(R,G,B_modif,A))
                            else:
                                pas3=pas1-pas2
                                B_modif=R
                                R_modif=R+pas3
                                image.putpixel((i,p),(R_modif,G,B_modif,A))
        ##3ème parite pour les teintes de 0 à -300
        if teinte_initiale < -200 and teinte_initiale >=-300:
            teinte=-0.01*teinte_02
            print(teinte)
            for i in range(0,x):
                for p in range (0,y):
                    (R,G,B,A)=image.getpixel((i,p))
                    ##pour un pixel avec rouge dominant
                    if R>B and R>=G :
                        if B>=G :
                            pas1=R-G
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-B
                            if pas2 >= pas1:
                                B_modif=B+pas1
                                image.putpixel((i,p),(R,G,B_modif,A))
                            else:
                                pas3=pas1-pas2
                                B_modif=R
                                R_modif=R-pas3
                                image.putpixel((i,p),(R_modif,G,B_modif,A))
                        else :
                            pas1=R-B
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=G-B
                            if pas2 >= pas1:
                                G_modif=G-pas1
                                image.putpixel((i,p),(R,G_modif,B,A))
                            else:
                                pas3=pas1-pas2
                                G_modif=B
                                B_modif=B+pas3
                                image.putpixel((i,p),(R,G_modif,B_modif,A))
                    ##pour un pixel avec bleu dominant
                    if B>=R and B>G :
                        if G>=R :
                            pas1=B-R
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=B-G
                            if pas2 >= pas1:
                                G_modif=G+pas1
                                image.putpixel((i,p),(R,G_modif,B,A))
                            else:
                                pas3=pas1-pas2
                                G_modif=B
                                B_modif=B-pas3
                                image.putpixel((i,p),(R,G_modif,B_modif,A))
                        else :
                            pas1=B-G
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=R-G
                            if pas2 >= pas1:
                                R_modif=R-pas1
                                image.putpixel((i,p),(R_modif,G,B,A))
                            else:
                                pas3=pas1-pas2
                                R_modif=G
                                G_modif=G+pas3
                                image.putpixel((i,p),(R_modif,G_modif,B,A))
                    ##pour un pixel avec vert dominant
                    if G>=B and G>R :
                        if R>=B :
                            pas1=G-B
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=G-R
                            if pas2 >= pas1:
                                R_modif=R+pas1
                                image.putpixel((i,p),(R_modif,G,B,A))
                            else:
                                pas3=pas1-pas2
                                R_modif=G
                                G_modif=G-pas3
                                image.putpixel((i,p),(R_modif,G_modif,B,A))
                        else :
                            pas1=G-R
                            pas1=pas1*teinte
                            pas1=int(pas1)
                            pas2=B-R
                            if pas2 >= pas1:
                                B_modif=B-pas1
                                image.putpixel((i,p),(R,G,B_modif,A))
                            else:
                                pas3=pas1-pas2
                                B_modif=R
                                R_modif=R+pas3
                                image.putpixel((i,p),(R_modif,G,B_modif,A))
    ##POUR TEINTE = 0
    if teinte_initiale == 0:
        print("Pourquoi tu lances ce programme si t'as pas besoin de teinter ton image ???")

    heure2 = datetime.now()
    print("Le programme a mis",heure2 - heure1,"pour s'éxecuter (hr/min/s)")##permet de calculer le temps, pour une grosse image avec une grosse modification, il prend jusqu'à 5 minutes
    return image

def seuil(image): ##le seuillage est une technique simple de binarisation d'une image en niveau de gris vers une image binaire dont les valeurs des pixels ne sont que 0 ou 1 (ici 0 ou 255)
    from PIL import Image, ImageEnhance
    x,y=image.size
    seuil=int(input("Indiquez la valeur du seuil souhatié (de 0 à 255)"))
    filter = ImageEnhance.Color(image)
    image = filter.enhance(0)##le filtre transforme l'image en noir et blanc
    image=image.convert('L')
    for i in range(0,x):
        for p in range (0,y):
            L=image.getpixel((i,p))
            if L >= seuil : ##si la valeur de gris est supérieur ou égal au seuil choisi, le pixel devient blanc
                image.putpixel((i,p),(255))
            else: ##sinon le pixel devient noir
                image.putpixel((i,p),(0))
    return image