# Créé par Alexa, le 01/03/2022 en Python 3.7
from PIL import Image
import Alexandre
import Noah

choix=0

nom=str(input("Veuillez entrez le nom de l'image sans son extension de fichier."))
extension=str(input("Veuillez entrer l'extension de votre fichier. (.png , .jpg ...)"))
fichier=nom+extension
image=Image.open(fichier).convert('RGBA')

while choix>8 or choix<1:
    choix=int(input("Quel filtre voulez-vous appliquer à votre image ?\n 1 - Ajoute un cadre.\n 2 - Effectue un seuil.\n 3 - Applique un effet miroir.\n 4 - Modifie la teinte de l'image.\n 5 - Applique un effet flou à l'image.\n 6 - assombrit votre image.\n 7 - Change les couleur aléatoirement.\n 8 - Augmente la saturation.\n "))
if choix==1:
    fichier=nom+" - cadre.png"
    image=Alexandre.cadre(image).save(fichier,"PNG")
elif choix==2:
    fichier=nom+" - seuillée.png"
    image=Noah.seuil(image).save(fichier,"PNG")
elif choix==3:
    fichier=nom+" - miroir.png"
    image=Alexandre.miroir(image).save(fichier,"PNG")
elif choix==4:
    fichier=nom+" - teintée.png"
    image=Noah.teinte(image).save(fichier,"PNG")
elif choix==5:
    fichier=nom+" - floutée.png"
    image=Alexandre.flou(image).save(fichier,"PNG")
elif choix==6:
    fichier=nom+" - sombre.png"
    image=Alexandre.sombre(image).save(fichier,"PNG")
elif choix==7:
    fichier=nom+" - random.png"
    image=Alexandre.randommiser(image).save(fichier,"PNG")
elif choix==8:
    fichier=nom+" - saturée.png"
    image=Alexandre.saturation(image).save(fichier,"PNG")
print("Done")