# Créé par Alexa, le 01/03/2022 en Python 3.7
from PIL import Image
import random

def cadre(image):
    taille=int(input("Entrez la taille des bordures"))
    l,h=image.size
    R=int(input("Entrez la nuance de rouge que vous voulez. (0-255)"))
    G=int(input("Entrez la nuance de vert que vous voulez. (0-255)"))
    B=int(input("Entrez la nuance de bleu que vous voulez. (0-255)"))
    image_cadre=Image.new("RGB",(l+(2*taille),h+(2*taille)),(R,G,B))
    for i in range(h):
        for y in range(l):
            image_cadre.putpixel((y+taille,i+taille),(image.getpixel((y,i))))
    return image_cadre

def miroir(image):
    l,h=image.size
    image_miroir=Image.new("RGB",(l,h))
    for i in range(h):
        for y in range(l):
            image_miroir.putpixel((-y,i),image.getpixel((y,i)))
    return image_miroir

def sombre(image):#tentatiuve raté de flou rencouverti
    l,h=image.size
    R,G,B,T=0,0,0,0
    image_flou=Image.new("RGB",(l,h))
    intencite=0
    if intencite<0 or intencite>50:
        intencite=int(input("Indiquez l'intencité que vous voulez appliquer. (1-50)"))
    for i in range(h):
        for y in range(l):
            R+=image.getpixel((y-intencite,i-intencite))[0]
            G+=image.getpixel((y-intencite,i-intencite))[1]
            B+=image.getpixel((y-intencite,i-intencite))[2]
            T+=image.getpixel((y-intencite,i-intencite))[3]
            R,G,B,T=R//intencite,G//intencite,B//intencite,T//intencite
            image_flou.putpixel((y,i),(R,G,B,T))
    return image_flou

def flou(image):
    l,h=image.size
    R,G,B,T=0,0,0,0
    image_flou=Image.new("RGB",(l,h))
    intencite=0
    while intencite<1 or intencite>100:
        intencite=int(input("Indiquez l'intencité du flou. (1-100)"))
    for i in range(h):
        for y in range(l):
            for x in range(intencite):
                R+=image.getpixel((y-x,i-x))[0]
                G+=image.getpixel((y-x,i-x))[1]
                B+=image.getpixel((y-x,i-x))[2]
                T+=image.getpixel((y-x,i-x))[3]
            R,G,B,T=R//intencite,G//intencite,B//intencite,T//intencite
            image_flou.putpixel((y,i),(R,G,B,T))
    return image_flou

def randommiser(image):
    l,h=image.size
    image_random=Image.new("RGB",(l,h))
    intencite=0
    while intencite<1 or intencite>50:
        intencite=int(input("Indiquez le nombre de fois que vous voulez l'appliquer. (1-50)"))
    for i in range(h):
        for y in range(l):
            R,G,B,T=image.getpixel((y,i))
            R+=(intencite-1)*random.randint(0,255)//intencite
            G+=(intencite-1)*random.randint(0,255)//intencite
            B+=(intencite-1)*random.randint(0,255)//intencite
            T+=(intencite-1)*random.randint(0,255)//intencite
            image_random.putpixel((y,i),(R,G,B,T))
    return image_random

def saturation(image): #dérivé du filtre teinte
    while saturation<1 or saturation<100:
        saturation=int(input("Entrez le niveau de saturation. (0-100)"))
    for i in range(0,x):
            for p in range (0,y):
                (R,G,B,A)=image.getpixel((i,p))
                ##pour un pixel avec rouge dominant
                if R>B and R>=G :
                    if B>G :
                        pas1=R-G
                        pas1=pas1*saturation
                        pas1=int(pas1)
                        pas2=R-B
                        if pas2 >= pas1:
                            B_modif=B+pas1
                            image.putpixel((i,p),(R,G,B_modif,A))
                        else:
                            pas3=pas1-pas2
                            B_modif=R
                            R_modif=R-pas3
                            image.putpixel((i,p),(R_modif,G,B_modif,A))
                    else :
                        pas1=R-B
                        pas1=pas1*saturation
                        pas1=int(pas1)
                        pas2=G-B
                        if pas2 >= pas1:
                            G_modif=G-pas1
                            image.putpixel((i,p),(R,G_modif,B,A))
                        else:
                            pas3=pas1-pas2
                            G_modif=B
                            B_modif=B+pas3
                            image.putpixel((i,p),(R,G_modif,B_modif,A))
                ##pour un pixel avec bleu dominant
                if B>=R and B>G :
                    if G>R :
                        pas1=B-R
                        pas1=pas1*saturation
                        pas1=int(pas1)
                        pas2=B-G
                        if pas2 >= pas1:
                            G_modif=G+pas1
                            image.putpixel((i,p),(R,G_modif,B,A))
                        else:
                            pas3=pas1-pas2
                            G_modif=B
                            B_modif=B-pas3
                            image.putpixel((i,p),(R,G_modif,B_modif,A))
                    else :
                        pas1=B-G
                        pas1=pas1*saturation
                        pas1=int(pas1)
                        pas2=B-R
                        if pas2 >= pas1:
                            R_modif=R-pas1
                            image.putpixel((i,p),(R_modif,G,B,A))
                        else:
                            pas3=pas1-pas2
                            R_modif=G
                            G_modif=G+pas3
                            image.putpixel((i,p),(R_modif,G_modif,B,A))
                ##pour un pixel avec vert dominant
                if G>=B and G>R :
                    if R>B :
                        pas1=G-B
                        pas1=pas1*saturation
                        pas1=int(pas1)
                        pas2=G-R
                        if pas2 >= pas1:
                            R_modif=R+pas1
                            image.putpixel((i,p),(R_modif,G,B,A))
                        else:
                            pas3=pas1-pas2
                            R_modif=G
                            G_modif=G-pas3
                            image.putpixel((i,p),(R_modif,G_modif,B,A))
                    else :
                        pas1=G-R
                        pas1=pas1*saturation
                        pas1=int(pas1)
                        pas2=B-R
                        if pas2 >= pas1:
                            B_modif=B-pas1
                            image.putpixel((i,p),(R,G,B_modif,A))
                        else:
                            pas3=pas1-pas2
                            B_modif=R
                            R_modif=R+pas3
                            image.putpixel((i,p),(R_modif,G,B_modif,A))
    return image_saturation