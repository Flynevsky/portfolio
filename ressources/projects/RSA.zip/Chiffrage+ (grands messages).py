import random
clef_publique_1=input("Entrez la première valeur de votre clef de chiffrage (la clef publique)")
clef_publique_2=input("Entrez la deuxième valeur de votre clef de chiffrage (la clef publique)")
n=int(clef_publique_1)
e=int(clef_publique_2)
message="ENTREZ LE MESSAGE A CHIFFRE ICI (EX : Hello World)"
message=str(message)
message_chiffre=""
chiffrement=0
caracteres=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","/","*","-","+","."," ",",",";",":","!","&","é","(","-","è","_","ç","à",")","=","^","$","ù","<",">","²","?","é","#","{","[","|","`","@","]","}","¨","£","µ","%","â","ê","î","ô","û","ä","ë","ï","ö","ü","ÿ","A","n","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","Ä","Ë","Ï","Ö","Ü","Â","Ê","Î","Ô","Û","€","'","0","B"]
raccourci=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9","&","é","(","-","è","_","ç","à",")",",","*","ù","!","~","û",";",":","/","ë","|","[","]","=","+","{","}","€","ê","¤","£",".","%","µ","ù","²","<",">","â","'","Â","Ê","Î","Ô","Û","ï"]
q=0
h=0
g=""
morceau_chiffrement=""
message_chiffrement=""
k=2
for lettre in message:
    for p in caracteres:
        if lettre==p:
            hexa=chr(random.randint(ord('A'), ord('F')))
            chiffrement=k**e%n
            chiffrement=str(chiffrement)
            if len(chiffrement)%2!=0:
                for g in chiffrement:
                    q=q+1
                    h=h+1
                    morceau_chiffrement=morceau_chiffrement+g
                    if h==len(chiffrement):
                        hexa=chr(random.randint(ord('A'), ord('F')))
                        g=int(g)
                        lettre_ra=raccourci[g]
                        message_chiffrement=message_chiffrement+lettre_ra+hexa
                        morceau_chiffrement=""
                        h=0
                        q=0
                    elif q==2:
                        q=0
                        morceau_chiffrement_1=int(morceau_chiffrement)
                        caracteres_ra=raccourci[morceau_chiffrement_1]
                        message_chiffrement=message_chiffrement+caracteres_ra
                        morceau_chiffrement=""
                message_chiffre=message_chiffre+message_chiffrement
                message_chiffrement=""
            else:
                for g in chiffrement:
                    q=q+1
                    h=h+1
                    morceau_chiffrement=morceau_chiffrement+g
                    if q==2:
                        morceau_chiffrement_1=int(morceau_chiffrement)
                        caracteres_ra=raccourci[morceau_chiffrement_1]
                        if h==len(chiffrement):
                            hexa=chr(random.randint(ord('A'), ord('F')))
                            message_chiffrement=message_chiffrement+caracteres_ra+hexa
                            h=0
                            q=0
                        else:
                            message_chiffrement=message_chiffrement+caracteres_ra
                            q=0
                        morceau_chiffrement=""
                message_chiffre=message_chiffre+message_chiffrement
                message_chiffrement=""
            k=2
            break
        k=k+1
print("Le message chiffré est :",message_chiffre)

