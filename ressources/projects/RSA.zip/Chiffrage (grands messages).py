import random
clef_publique_1=input("Entrez la première valeur de votre clef de chiffrage (la clef publique)")
clef_publique_2=input("Entrez la deuxième valeur de votre clef de chiffrage (la clef publique)")
n=int(clef_publique_1)
e=int(clef_publique_2)
message="ENTREZ LE MESSAGE A CHIFFRE ICI (EX : Hello World)"
message_chiffre=""
message_trad=""
chiffrement=0
caracteres=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","/","*","-","+","."," ",",",";",":","!","&","é","(","-","è","_","ç","à",")","=","^","$","ù","<",">","²","?","é","#","{","[","|","`","@","]","}","¨","£","µ","%","â","ê","î","ô","û","ä","ë","ï","ö","ü","ÿ","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","Ä","Ë","Ï","Ö","Ü","Â","Ê","Î","Ô","Û","€","'","0"]
raccourci=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9","&","é","(","-","è","_","ç","à",")",",","*","?","!","~","û",";",":","/","ë","|","[","]","=","+","{","}","€","ê","¤","£",".","%","µ","ù","²","<",">","â","'","Â","Ê","Î","Ô","Û","ï"]
k=2
q=0
h=0
partie_trad=""
partie_chiffrement=[]
partie=""
for lettre in message:
    for p in caracteres:
        if lettre==p:
            hexa=chr(random.randint(ord('A'), ord('F')))
            chiffrement=k**e%n
            chiffrement=str(chiffrement)
            if len(chiffrement)%2==0:
                for i in chiffrement :
                    h=h+1
                    partie=partie+i
                    if h==2:
                        trad=raccourci[int(partie)]
                        message_trad=message_trad+trad
                        partie=""
                        trad=""
                        h=0
            if len(chiffrement)%2!=0:
                for i in chiffrement :
                    h=h+1
                    q=q+1
                    partie=partie+i
                    if h==2:
                        trad=raccourci[int(partie)]
                        message_trad=message_trad+trad
                        partie=""
                        trad=""
                        h=0
                    if q==len(chiffrement):
                        trad=raccourci[int(partie)]
                        message_trad=message_trad+trad
                        partie=""
                        trad=""
                        h=0
                        q=0
            message_trad=message_trad+hexa
            k=2
            break
        k=k+1
print("Le message chiffré est :",message_trad)
