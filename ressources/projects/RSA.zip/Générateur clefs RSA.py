message_dechiffre=""
nb_clef_nul=0
def clef():
    import random
    import math
    clef_publique_1=0
    clef_privee_1=0
    clef_publique=0
    clef_privee=0
    min = 0
    max = 200
    while clef_publique==0:
        nb_premiers=[]
        for n in range(min,max + 1):
           if n > 1:
               for i in range(2,n):
                   if (n % i) == 0:
                       break
               else:
                   nb_premiers.append(n)
        nb_premier_1=nb_premiers[random.randint(0,len(nb_premiers)-1)]
        nb_premier_2=nb_premiers[random.randint(0,len(nb_premiers)-1)]
        while nb_premier_1==nb_premier_2:
            nb_premier_2=nb_premiers[random.randint(0,len(nb_premiers)-1)]
        module_de_chiffrement=nb_premier_1*nb_premier_2
        L=(nb_premier_1-1)*(nb_premier_2-1)
        for n in range (1,L):
            o = math.gcd(n,L)
            if o == 1:
                j=L/n
                j=int(j)
                if L-(n*j)==1:
                    e=n
                    inverse_modulaire_d = pow(e, L-1, L)
                    clef_publique=clef_publique_1
                    clef_privee=clef_privee_1
                    clef_publique_1=[module_de_chiffrement,e]
                    clef_privee_1=[module_de_chiffrement,inverse_modulaire_d]
    return(clef_publique,clef_privee)
def faire_clef():
    clef_1,clef_2=clef()

    while clef_1[1]==clef_2[1]:
        clef_1,clef_2=clef()

    import random
    clef_publique_1=clef_1[0]
    clef_publique_2=clef_1[1]
    n=int(clef_publique_1)
    e=int(clef_publique_2)
    message="abcdefghijklmnopqrstuvwxyz123456789/*-+. ,;:!&é(-è_çà)=^$ù<>²?é#{[|`@]}¨£µ%âêîôûäëïöüÿABCDEFGHIJKLMNOPQRSTUVWXYZÄËÏÖÜÂÊÎÔÛ€'0"
    message=str(message)
    message_chiffre=""
    chiffrement=0
    caracteres=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","/","*","-","+","."," ",",",";",":","!","&","é","(","-","è","_","ç","à",")","=","^","$","ù","<",">","²","?","é","#","{","[","|","`","@","]","}","¨","£","µ","%","â","ê","î","ô","û","ä","ë","ï","ö","ü","ÿ","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","Ä","Ë","Ï","Ö","Ü","Â","Ê","Î","Ô","Û","€","'","0"]
    raccourci=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9","&","é","(","-","è","_","ç","à",")",",","*","?","!","~","û",";",":","/","ë","|","[","]","=","+","{","}","€","ê","¤","£",".","%","µ","ù","²","<",">","â","'","Â","Ê","Î","Ô","Û","ï"]
    q=0
    h=0
    g=""
    morceau_chiffrement=""
    message_chiffrement=""
    k=2
    for lettre in message:
        for p in caracteres:
            if lettre==p:
                hexa=chr(random.randint(ord('A'), ord('F')))
                chiffrement=k**e%n
                chiffrement=str(chiffrement)
                if len(chiffrement)%2!=0:
                    for g in chiffrement:
                        q=q+1
                        h=h+1
                        morceau_chiffrement=morceau_chiffrement+g
                        if h==len(chiffrement):
                            hexa=chr(random.randint(ord('A'), ord('F')))
                            g=int(g)
                            lettre_ra=raccourci[g]
                            message_chiffrement=message_chiffrement+lettre_ra+hexa
                            morceau_chiffrement=""
                            h=0
                            q=0
                        elif q==2:
                            q=0
                            morceau_chiffrement_1=int(morceau_chiffrement)
                            caracteres_ra=raccourci[morceau_chiffrement_1]
                            message_chiffrement=message_chiffrement+caracteres_ra
                            morceau_chiffrement=""
                    message_chiffre=message_chiffre+message_chiffrement
                    message_chiffrement=""
                else:
                    for g in chiffrement:
                        q=q+1
                        h=h+1
                        morceau_chiffrement=morceau_chiffrement+g
                        if q==2:
                            morceau_chiffrement_1=int(morceau_chiffrement)
                            caracteres_ra=raccourci[morceau_chiffrement_1]
                            if h==len(chiffrement):
                                hexa=chr(random.randint(ord('A'), ord('F')))
                                message_chiffrement=message_chiffrement+caracteres_ra+hexa
                                h=0
                                q=0
                            else:
                                message_chiffrement=message_chiffrement+caracteres_ra
                                q=0
                            morceau_chiffrement=""
                    message_chiffre=message_chiffre+message_chiffrement
                    message_chiffrement=""
                k=2
                break
            k=k+1

    clef_privee_1=clef_2[0]
    clef_privee_2=clef_2[1]
    n=int(clef_privee_1)
    d=int(clef_privee_2)
    message=message_chiffre
    message=str(message)
    message_dechiffre=""
    chiffrement=0
    caracteres=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","/","*","-","+","."," ",",",";",":","!","&","é","(","-","è","_","ç","à",")","=","^","$","ù","<",">","²","?","é","#","{","[","|","`","@","]","}","¨","£","µ","%","â","ê","î","ô","û","ä","ë","ï","ö","ü","ÿ","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","Ä","Ë","Ï","Ö","Ü","Â","Ê","Î","Ô","Û","€","'","0"]
    raccourci=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9","&","é","(","-","è","_","ç","à",")",",","*","?","!","~","û",";",":","/","ë","|","[","]","=","+","{","}","€","ê","¤","£",".","%","µ","ù","²","<",">","â","'","Â","Ê","Î","Ô","Û","ï"]
    lettres=["A","B","C","D","E","F"]
    k=0
    i=-1
    f=0
    chiffre=""
    dechiffrement=""
    mot_dechiffrement=""
    for lettre in message:
        for p in lettres:
            if lettre==p:
                for t in chiffre :
                    stop=1
                    for y in raccourci:
                        if stop==1:
                            i=i+1
                            if t==y:
                                dechiffrement=str(i)
                                mot_dechiffrement=mot_dechiffrement+dechiffrement
                                i=-1
                                stop=0
                chiffre=int(mot_dechiffrement)
                caractere_dechiffre=chiffre**d%n
                f=caractere_dechiffre-2
                if f > 126 :
                    break
                else :
                    caractere_dechiffre=caracteres[f]
                message_dechiffre=message_dechiffre+caractere_dechiffre
                chiffre=""
                mot_dechiffrement=""
                k=1
            if f > 126 :
                    break
        if f > 126 :
                    break
        if k==0 :
            chiffre=chiffre+lettre
        k=0
    return(clef_1,clef_2,message_dechiffre)
clef_1,clef_2,message_dechiffre=faire_clef()
while message_dechiffre!="abcdefghijklmnopqrstuvwxyz123456789/*-+. ,;:!&é(-è_çà)=^$ù<>²?é#{[|`@]}¨£µ%âêîôûäëïöüÿABCDEFGHIJKLMNOPQRSTUVWXYZÄËÏÖÜÂÊÎÔÛ€'0" :
    nb_clef_nul=nb_clef_nul+1
    clef_1,clef_2,message_dechiffre=faire_clef()
print("Votre clef publique de chiffrement est :",clef_1,"\nVotre clef privée de déchiffrement est :",clef_2)
if nb_clef_nul == 1 :
    print(nb_clef_nul,"clef n'a pas marchée")
else :
    print(nb_clef_nul,"clefs n'ont pas marchées")