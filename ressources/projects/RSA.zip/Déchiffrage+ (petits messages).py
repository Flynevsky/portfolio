
clef_privee_1=input("Entrez la première valeur de votre clef de déchiffrage (la clef privée)")
clef_privee_2=input("Entrez la deuxième valeur de votre clef de déchiffrage (la clef privée)")
n=int(clef_privee_1)
d=int(clef_privee_2)
message=input("Entrez le message à déchiffrer (Ex : pfCogElgAqcBpfFweD}F")
message=str(message)
message_dechiffre=""
chiffrement=0
caracteres=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","/","*","-","+","."," ",",",";",":","!","&","é","(","-","è","_","ç","à",")","=","^","$","ù","<",">","²","?","é","#","{","[","|","`","@","]","}","¨","£","µ","%","â","ê","î","ô","û","ä","ë","ï","ö","ü","ÿ","A","n","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","Ä","Ë","Ï","Ö","Ü","Â","Ê","Î","Ô","Û","€","'","0","B"]
raccourci=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9","&","é","(","-","è","_","ç","à",")",",","*","ù","!","~","û",";",":","/","ë","|","[","]","=","+","{","}","€","ê","¤","£",".","%","µ","ù","²","<",">","â","'","Â","Ê","Î","Ô","Û","ï"]
lettres=["A","B","C","D","E","F"]
k=0
i=-1
chiffre=""
dechiffrement=""
mot_dechiffrement=""
for lettre in message:
    for p in lettres:
        if lettre==p:
            for t in chiffre :
                stop=1
                for y in raccourci:
                    if stop==1:
                        i=i+1
                        if t==y:
                            dechiffrement=str(i)
                            mot_dechiffrement=mot_dechiffrement+dechiffrement
                            i=-1
                            stop=0
            chiffre=int(mot_dechiffrement)
            caractere_dechiffre=chiffre**d%n
            f=caractere_dechiffre-2
            caractere_dechiffre=caracteres[f]
            message_dechiffre=message_dechiffre+caractere_dechiffre
            chiffre=""
            mot_dechiffrement=""
            k=1
    if k==0 :
        chiffre=chiffre+lettre
    k=0
print("Le message déchiffré est :",message_dechiffre)
