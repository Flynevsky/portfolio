
def clef():
    import random
    import math
    clef_publique_1=0
    clef_privee_1=0
    clef_publique=0
    clef_privee=0
    min = 0
    max = 100
    while clef_publique==0:
        nb_premiers=[]
        for n in range(min,max + 1):
           if n > 1:
               for i in range(2,n):
                   if (n % i) == 0:
                       break
               else:
                   nb_premiers.append(n)
        nb_premier_1=nb_premiers[random.randint(0,len(nb_premiers)-1)]
        nb_premier_2=nb_premiers[random.randint(0,len(nb_premiers)-1)]
        while nb_premier_1==nb_premier_2:
            nb_premier_2=nb_premiers[random.randint(0,len(nb_premiers)-1)]
        module_de_chiffrement=nb_premier_1*nb_premier_2
        L=(nb_premier_1-1)*(nb_premier_2-1)
        for n in range (1,L):
            o = math.gcd(n,L)
            if o == 1:
                j=L/n
                j=int(j)
                if L-(n*j)==1:
                    e=n
                    inverse_modulaire_d = pow(e, L-1, L)
                    clef_publique=clef_publique_1
                    clef_privee=clef_privee_1
                    clef_publique_1=[module_de_chiffrement,e]
                    clef_privee_1=[module_de_chiffrement,inverse_modulaire_d]
    return(clef_publique,clef_privee)

clef_1,clef_2=clef()
if clef_1[1]<100 and clef_2[1]>128 and clef_1[0]>128 and clef_1[1]!=clef_2[1]:
    print("Votre clef de chiffrement est :",clef_1)
    print("Votre clef de déchiffrement est :",clef_2)
else:
    while clef_1[1]>=100 or clef_2[1]<=128 or clef_1[0]<=128 or clef_1[1]==clef_2[1]:
        clef_1,clef_2=clef()
    print("Votre clef de chiffrement est :",clef_1)
    print("Votre clef de déchiffrement est :",clef_2)





